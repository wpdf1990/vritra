-- --------------------------------------------------------
-- Host:                         89.43.62.116
-- Server version:               5.5.40-0ubuntu0.14.04.1 - (Ubuntu)
-- Server OS:                    debian-linux-gnu
-- HeidiSQL Version:             9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for fusioncms
CREATE DATABASE IF NOT EXISTS `fusioncms` /*!40100 DEFAULT CHARACTER SET utf16 */;
USE `fusioncms`;


-- Dumping structure for table fusioncms.account_data
CREATE TABLE IF NOT EXISTS `account_data` (
  `id` int(11) NOT NULL,
  `vp` int(11) DEFAULT '0',
  `dp` int(11) DEFAULT '0',
  `total_votes` int(11) NOT NULL DEFAULT '0',
  `location` varchar(255) DEFAULT NULL,
  `nickname` varchar(32) DEFAULT NULL,
  `language` varchar(40) NOT NULL DEFAULT 'english',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.acl_account_groups
CREATE TABLE IF NOT EXISTS `acl_account_groups` (
  `account_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`account_id`,`group_id`),
  UNIQUE KEY `account_id_group_id` (`account_id`,`group_id`),
  KEY `FK__acl_groups` (`group_id`),
  CONSTRAINT `FK__acl_groups` FOREIGN KEY (`group_id`) REFERENCES `acl_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.acl_account_permissions
CREATE TABLE IF NOT EXISTS `acl_account_permissions` (
  `account_id` int(10) unsigned NOT NULL,
  `permission_name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `value` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_id_permission_id` (`account_id`,`permission_name`,`module`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.acl_account_roles
CREATE TABLE IF NOT EXISTS `acl_account_roles` (
  `account_id` int(11) unsigned NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  PRIMARY KEY (`account_id`,`role_name`),
  UNIQUE KEY `account_id_role_name` (`account_id`,`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.acl_groups
CREATE TABLE IF NOT EXISTS `acl_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `color` varchar(7) DEFAULT '#FFFFFF',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.acl_group_roles
CREATE TABLE IF NOT EXISTS `acl_group_roles` (
  `group_id` int(10) unsigned NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  PRIMARY KEY (`group_id`,`role_name`,`module`),
  UNIQUE KEY `group_id_role_id` (`group_id`,`role_name`,`module`),
  CONSTRAINT `FK__groups` FOREIGN KEY (`group_id`) REFERENCES `acl_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.acl_roles
CREATE TABLE IF NOT EXISTS `acl_roles` (
  `name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT '',
  PRIMARY KEY (`name`,`module`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.acl_roles_permissions
CREATE TABLE IF NOT EXISTS `acl_roles_permissions` (
  `role_name` varchar(50) NOT NULL,
  `permission_name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `value` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_name`,`permission_name`,`module`),
  UNIQUE KEY `role_name_permission_name` (`role_name`,`permission_name`,`module`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.articles
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `headline` text,
  `content` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `comments` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.article_tag
CREATE TABLE IF NOT EXISTS `article_tag` (
  `article_id` int(11) NOT NULL,
  `tag_id` int(10) NOT NULL,
  PRIMARY KEY (`article_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.banlist_pics
CREATE TABLE IF NOT EXISTS `banlist_pics` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `account` int(5) unsigned NOT NULL,
  `pic` varchar(60) NOT NULL,
  `uploaded_by` int(5) unsigned NOT NULL,
  `uploaded_date` int(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.changelog
CREATE TABLE IF NOT EXISTS `changelog` (
  `change_id` int(10) NOT NULL AUTO_INCREMENT,
  `changelog` text NOT NULL,
  `author` varchar(50) NOT NULL,
  `type` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`change_id`),
  KEY `FK_changelog_changelog_type` (`type`),
  CONSTRAINT `FK_changelog_changelog_type` FOREIGN KEY (`type`) REFERENCES `changelog_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.changelog_type
CREATE TABLE IF NOT EXISTS `changelog_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `typeName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.ci_sessions
CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.comments
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `timestamp` int(11) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `is_gm` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.daily_signups
CREATE TABLE IF NOT EXISTS `daily_signups` (
  `date` varchar(255) NOT NULL DEFAULT '',
  `amount` int(11) DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.image_slider
CREATE TABLE IF NOT EXISTS `image_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT '#',
  `text` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.item_display
CREATE TABLE IF NOT EXISTS `item_display` (
  `entry` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `displayid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Item System';

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.logs
CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `logType` varchar(255) NOT NULL,
  `logMessage` text NOT NULL,
  `user` int(11) unsigned DEFAULT NULL,
  `ip` varchar(45) NOT NULL,
  `custom` text,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.menu
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` text,
  `link` varchar(255) DEFAULT '#',
  `side` varchar(255) DEFAULT 'top',
  `rank` int(11) NOT NULL,
  `specific_rank` tinyint(1) NOT NULL DEFAULT '0',
  `order` int(11) DEFAULT NULL,
  `direct_link` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Is it a direct link or not? is needed for the ajax.',
  `permission` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_menu_ranks` (`rank`),
  CONSTRAINT `FK_menu_ranks` FOREIGN KEY (`rank`) REFERENCES `ranks` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.monthly_income
CREATE TABLE IF NOT EXISTS `monthly_income` (
  `month` varchar(255) NOT NULL DEFAULT '',
  `amount` int(11) DEFAULT '0',
  PRIMARY KEY (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.monthly_votes
CREATE TABLE IF NOT EXISTS `monthly_votes` (
  `month` varchar(255) NOT NULL DEFAULT '',
  `amount` int(11) DEFAULT '0',
  PRIMARY KEY (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.order_log
CREATE TABLE IF NOT EXISTS `order_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `completed` int(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `vp_cost` int(11) DEFAULT NULL,
  `dp_cost` int(11) DEFAULT NULL,
  `cart` text,
  `timestamp` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.pages
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `name` text,
  `content` text,
  `permission` varchar(50) DEFAULT NULL,
  `rank_needed` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `identifier` (`identifier`),
  KEY `fk_rank_needed_ranks` (`rank_needed`),
  CONSTRAINT `fk_rank_needed_ranks` FOREIGN KEY (`rank_needed`) REFERENCES `ranks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.password_recovery_key
CREATE TABLE IF NOT EXISTS `password_recovery_key` (
  `recoverykey` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `time` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.paygol_logs
CREATE TABLE IF NOT EXISTS `paygol_logs` (
  `message_id` varchar(255) NOT NULL DEFAULT '',
  `service_id` varchar(255) DEFAULT NULL,
  `shortcode` varchar(255) DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `custom` varchar(255) DEFAULT NULL,
  `points` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `timestamp` int(11) DEFAULT NULL,
  `converted_price` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.paypal_logs
CREATE TABLE IF NOT EXISTS `paypal_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_status` varchar(50) NOT NULL,
  `payment_amount` double NOT NULL,
  `payment_currency` varchar(10) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `receiver_email` varchar(255) NOT NULL,
  `payer_email` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `validated` int(1) DEFAULT '0',
  `error` text,
  `pending_reason` text,
  `timestamp` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.pending_accounts
CREATE TABLE IF NOT EXISTS `pending_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `expansion` int(3) DEFAULT NULL,
  `timestamp` int(11) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.private_message
CREATE TABLE IF NOT EXISTS `private_message` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `message` text NOT NULL,
  `time` int(10) NOT NULL,
  `read` int(1) DEFAULT '0',
  `deleted_user` int(1) DEFAULT '0',
  `deleted_sender` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_private_message_account_data` (`user_id`),
  KEY `FK_private_message_account_data_2` (`sender_id`),
  CONSTRAINT `FK_private_message_account_data` FOREIGN KEY (`user_id`) REFERENCES `account_data` (`id`),
  CONSTRAINT `FK_private_message_account_data_2` FOREIGN KEY (`sender_id`) REFERENCES `account_data` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.ranks
CREATE TABLE IF NOT EXISTS `ranks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rank_name` varchar(50) DEFAULT 'RANK',
  `access_id` varchar(10) DEFAULT '0',
  `is_gm` int(1) DEFAULT '0',
  `is_dev` int(1) DEFAULT '0',
  `is_admin` int(1) DEFAULT '0',
  `is_owner` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.realms
CREATE TABLE IF NOT EXISTS `realms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `char_database` varchar(255) DEFAULT NULL,
  `world_database` varchar(255) DEFAULT NULL,
  `cap` int(5) DEFAULT '100',
  `realmName` varchar(255) DEFAULT NULL,
  `console_username` varchar(255) DEFAULT NULL,
  `console_password` varchar(255) DEFAULT NULL,
  `console_port` int(6) DEFAULT NULL,
  `emulator` varchar(255) DEFAULT NULL,
  `realm_port` int(11) DEFAULT NULL,
  `override_port_world` int(11) DEFAULT NULL,
  `override_username_world` varchar(255) DEFAULT NULL,
  `override_password_world` varchar(255) DEFAULT NULL,
  `override_hostname_world` varchar(255) DEFAULT NULL,
  `override_port_char` int(11) DEFAULT NULL,
  `override_username_char` varchar(255) DEFAULT NULL,
  `override_password_char` varchar(255) DEFAULT NULL,
  `override_hostname_char` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.shouts
CREATE TABLE IF NOT EXISTS `shouts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `author` int(30) NOT NULL,
  `content` varchar(255) NOT NULL,
  `date` int(10) NOT NULL,
  `is_gm` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_shouts_account_data` (`author`),
  CONSTRAINT `FK_shouts_account_data` FOREIGN KEY (`author`) REFERENCES `account_data` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.sideboxes
CREATE TABLE IF NOT EXISTS `sideboxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '',
  `displayName` text,
  `rank_needed` int(10) NOT NULL DEFAULT '1',
  `order` int(11) DEFAULT '100',
  `permission` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sb_rank_needed` (`rank_needed`),
  CONSTRAINT `fk_sb_rank_needed` FOREIGN KEY (`rank_needed`) REFERENCES `ranks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.sideboxes_custom
CREATE TABLE IF NOT EXISTS `sideboxes_custom` (
  `sidebox_id` int(10) NOT NULL,
  `content` text NOT NULL,
  UNIQUE KEY `sidebox_id` (`sidebox_id`),
  CONSTRAINT `FK_sideboxes_custom_sideboxes` FOREIGN KEY (`sidebox_id`) REFERENCES `sideboxes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.sideboxes_poll_answers
CREATE TABLE IF NOT EXISTS `sideboxes_poll_answers` (
  `answerid` int(10) NOT NULL AUTO_INCREMENT,
  `questionid` int(10) NOT NULL,
  `answer` varchar(50) NOT NULL,
  PRIMARY KEY (`answerid`),
  KEY `FK__sideboxes_poll_questions` (`questionid`),
  CONSTRAINT `FK__sideboxes_poll_questions` FOREIGN KEY (`questionid`) REFERENCES `sideboxes_poll_questions` (`questionid`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.sideboxes_poll_questions
CREATE TABLE IF NOT EXISTS `sideboxes_poll_questions` (
  `questionid` int(10) NOT NULL AUTO_INCREMENT,
  `question` varchar(50) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.sideboxes_poll_votes
CREATE TABLE IF NOT EXISTS `sideboxes_poll_votes` (
  `questionid` int(11) DEFAULT NULL,
  `answerid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  KEY `fk_answers` (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.spelltext_en
CREATE TABLE IF NOT EXISTS `spelltext_en` (
  `spellId` int(11) NOT NULL,
  `spellText` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.store_groups
CREATE TABLE IF NOT EXISTS `store_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `orderNumber` int(8) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.store_items
CREATE TABLE IF NOT EXISTS `store_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` text,
  `name` varchar(255) DEFAULT NULL,
  `quality` int(2) DEFAULT NULL,
  `vp_price` int(4) DEFAULT NULL,
  `dp_price` int(4) DEFAULT NULL,
  `realm` int(3) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT 'inv_misc_questionmark',
  `group` int(11) DEFAULT NULL,
  `query` text,
  `query_database` varchar(50) DEFAULT '',
  `query_need_character` int(1) DEFAULT '0',
  `command` text,
  `command_need_character` int(1) DEFAULT NULL,
  `require_character_offline` int(1) NOT NULL DEFAULT '0',
  `tooltip` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_group` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.tag
CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.teleport_locations
CREATE TABLE IF NOT EXISTS `teleport_locations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT 'Unnamed',
  `description` varchar(255) DEFAULT NULL,
  `x` float DEFAULT '0',
  `y` float DEFAULT '0',
  `z` float DEFAULT '0',
  `orientation` float DEFAULT '0',
  `mapId` smallint(6) DEFAULT '0',
  `vpCost` int(11) DEFAULT '0',
  `dpCost` int(11) DEFAULT '0',
  `goldCost` int(11) DEFAULT '0',
  `realm` int(11) DEFAULT '1',
  `required_faction` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `realm_fk` (`realm`),
  CONSTRAINT `realm_fk` FOREIGN KEY (`realm`) REFERENCES `realms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.visitor_log
CREATE TABLE IF NOT EXISTS `visitor_log` (
  `date` varchar(10) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.vote_log
CREATE TABLE IF NOT EXISTS `vote_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `vote_site_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(50) NOT NULL,
  `ip` varchar(50) NOT NULL DEFAULT '127.0.0.1',
  `time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_vote_log_vote_sites` (`vote_site_id`),
  CONSTRAINT `FK_vote_log_vote_sites` FOREIGN KEY (`vote_site_id`) REFERENCES `vote_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table fusioncms.vote_sites
CREATE TABLE IF NOT EXISTS `vote_sites` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `vote_sitename` varchar(50) DEFAULT 'FusionCMS',
  `vote_url` varchar(255) DEFAULT 'http://',
  `vote_image` varchar(255) DEFAULT NULL,
  `hour_interval` int(10) NOT NULL DEFAULT '12',
  `points_per_vote` tinyint(4) NOT NULL DEFAULT '1',
  `callback_enabled` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
